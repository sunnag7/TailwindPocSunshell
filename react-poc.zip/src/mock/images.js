import imageHeroBannerUrl1 from '../img/hero-banner1.jpg';
import imageHeroBannerUrl2 from '../img/hero-banner5.jpg';
import imageHeroBannerUrl3 from '../img/hero-banner4.jpg';

const dataImages = [
  {
    imageUrl: imageHeroBannerUrl1,
    placeHolder: "Flower 1",
    quote: "the flower that blooms in adversity is the rarest and most beautiful of all.",
    author: "Dadi Janki",
  },
  {
    imageUrl: imageHeroBannerUrl2,
    placeHolder: "Flower 2",
    quote: "the flower that blooms in adversity is the rarest and most beautiful of all. 2",
    author: "Dadi Janki2",
  },
  {
    imageUrl: imageHeroBannerUrl3,
    placeHolder: "Flower 3",
    quote: "the flower that blooms in adversity is the rarest and most beautiful of all. 3",
    author: "Dadi Janki3",
  },
];
export default dataImages;