const jsonData = [
  {
    "id": 1,
    "title": "welcome",
    "text": "to a journey of the heart",
    "subtext": "This is a space where you can release, recharge, renew, and remember what really matters",
  },
  {
    "id": 2,
    "title": "breath",
    "text": "every breath, every moment, is precious.",
    "subtext": "The seed of a more peaceful world begins with the seed of peace within us.",
  },
  {
    "id": 3,
    "title": "bytes",
    "text": "a drop of wisdom can water the thirst for real inner change",
    "subtext": "At a personal and collective level, our world is shifting",
  },
  {
    "id": 4,
    "title": "briefing",
    "text": "a drop of wisdom can water the thirst for real inner change",
    "subtext": "Who we are",
    "subtext2": "what is our vision...",
  },
];
export default jsonData;