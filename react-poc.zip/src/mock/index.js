import Images from './images';
import jsonData from './jsonData';
export { Images, jsonData };