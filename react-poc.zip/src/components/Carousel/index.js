import React, {  useEffect } from 'react';
import Thumbnail from '../Thumbnail';
import DotIcon from '../DotIcon';
import arrowDown from '../../img/arrow-down.png';

const Carousel = ({ children, time }) => {
  const [index, setIndex] = React.useState(0);
  const keys = children.map((child, index) => index);

  useEffect(() => {
    const interval = setInterval(() => {
      const newIndex = (index + 1) % keys.length;
      setIndex(newIndex);
    }, time);
    return () => clearInterval(interval);
  });
  
  const _slides = () => {
    return children.map((child, idx) => (
      <Thumbnail key={idx} id={idx} selectedKey={index}>
        {child}
      </Thumbnail>
    ));
  }

  const _sliderDots = () => {
    return keys.map(key => (
      <span key={key} onClick={() => setIndex(key)}>
        {<DotIcon selected={key === index} />}
      </span>
    ));
  }

  return (
    <div className="m-auto">
        <div className="slider-height">
          { _slides() }
        </div>
        <div className="slider-dots flex justify-center">
          { _sliderDots() }
        </div>
          <a href="#welcome" className="scroll-down">
            <img src={arrowDown} alt="arrowDown" />
          </a>
    </div>
  );
}

export default Carousel;