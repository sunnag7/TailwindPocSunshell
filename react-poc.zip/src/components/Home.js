import React from 'react';
import { jsonData } from '../mock';

function Home() {
  const data = jsonData;
  return (
    <section className="" id="welcome">
    <div className="container mx-auto text-right">
      <div className="px-6 welcome-section bg-section">
        <div className="welcome-content-box">
          <h1 className="text-gray leading-none mb-4 font-filosofia text-left"><em>{data[0].title}</em></h1>
          <h4 className="text-red leading-none text-3xl md:text-4xl font-filosofia mb-10 text-left pl-0 md:pl-20">{data[0].text}</h4>
          <p className="font-medium text-gray-500 text-left md:text-right text-xl md:text-2xl font-avenir">{data[0].subtext}</p>
        </div>
      </div>
    </div>
  </section>
  )
};

export default Home;
