import React from 'react';
import { Images } from '../../mock';

const Slides = () => (
  Images.map((image, index) => 
  <div key={index}>
      <img src={image.imageUrl} alt={image.placeHolder} className={image.placeHolder}  /> 
      <div className="hero-copy">
        <h3 className="text-left"><em>{image.quote}</em></h3>
        <h3 className="text-right"><em>- {image.author}</em></h3>
      </div>
  </div>
   
  )

  
);

export default Slides;