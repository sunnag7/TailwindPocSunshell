import React from 'react';
import { jsonData } from '../mock';

function Briefing() {
  const data = jsonData;
    return (
  <section className="bg-purple" id="briefing">
    <div className="container mx-auto">
      <div className="px-6 briefing-section bg-section">
        <div className="briefing-content-box">
          <h1 className="text-purple leading-none mb-4 font-filosofia">{data[3].title}</h1>
          <h4 className="text-red leading-none text-4xl font-filosofia mb-10"><em>{data[3].text}</em></h4>
          <p className="font-medium text-gray-500 text-2xl font-avenir">{data[3].subtext}</p>
          <p className="font-medium text-gray-500 text-2xl font-avenir mb-5">{data[3].subtext2}</p>
          <a href="#" className="btn btn-purple leading-none text-2xl font-filosofia">learn</a>
        </div>
      </div>
    </div>
    </section>
  )
};

export default Briefing;
